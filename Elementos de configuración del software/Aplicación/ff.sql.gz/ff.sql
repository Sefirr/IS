-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- Generation Time: Sep 11, 2014 at 01:41 AM
-- Server version: 5.5.34
-- PHP Version: 5.5.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ff`
--

-- --------------------------------------------------------

--
-- Table structure for table `Orders`
--

CREATE TABLE `Orders` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Vendor_Name` varchar(50) DEFAULT NULL,
  `Date` date DEFAULT NULL,
  `Confirmed` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `Orders`
--

INSERT INTO `Orders` (`Id`, `Vendor_Name`, `Date`, `Confirmed`) VALUES
(1, 'Juan', '2014-01-09', 1),
(2, 'Pedro', '2014-01-09', 0),
(3, 'April', '2014-01-09', 1);

-- --------------------------------------------------------

--
-- Table structure for table `Orders_Pr`
--

CREATE TABLE `Orders_Pr` (
  `Order_Id` int(11) NOT NULL,
  `Product_Id` int(11) NOT NULL,
  `Product_Amount` int(11) NOT NULL,
  PRIMARY KEY (`Order_Id`,`Product_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Sales`
--

CREATE TABLE `Sales` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Total` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `Sales_Pr`
--

CREATE TABLE `Sales_Pr` (
  `Sale_Id` int(11) NOT NULL,
  `Product_Id` int(11) NOT NULL,
  `Product_Amount` int(11) NOT NULL,
  PRIMARY KEY (`Sale_Id`,`Product_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Staff`
--

CREATE TABLE `Staff` (
  `Permission` tinyint(3) unsigned DEFAULT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `User` varchar(50) DEFAULT NULL,
  `Pass` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Staff`
--

INSERT INTO `Staff` (`Permission`, `Name`, `User`, `Pass`) VALUES
(3, 'Pedro Gerente', 'gerente', 'gerente'),
(4, 'Pablo Vendedor', 'vendor', 'vendor'),
(2, 'John Doe', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `Stock`
--

CREATE TABLE `Stock` (
  `Id` int(11) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Type` int(11) DEFAULT NULL,
  `Price` decimal(5,2) DEFAULT NULL,
  `Amount` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Stock`
--

INSERT INTO `Stock` (`Id`, `Name`, `Type`, `Price`, `Amount`) VALUES
(0, 'Hamburguesa de carne de vacuno', 1, 5.95, 99),
(1, 'Patatas fritas', 2, 1.00, 99),
(2, 'Ensalada César', 3, 2.35, 99),
(3, 'Cola Grande', 4, 1.40, 99),
(4, 'Agua Fontvella', 4, 1.00, 99);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
